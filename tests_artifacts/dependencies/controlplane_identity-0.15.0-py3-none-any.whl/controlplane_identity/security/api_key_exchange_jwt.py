"""HS256 JWT minted by the gateway after API key validation (not Keycloak)."""

from __future__ import annotations

import time
import uuid
from typing import Any

import jwt
from jwt import InvalidTokenError

from controlplane_identity.configuration import settings, api_key_exchange_secrets
from controlplane_identity.nightly import require_original_run

ISSUER = "https://spanopticon.internal/api-key"
ALG = "HS256"
TTL_SECONDS = 300


def mint_api_key_session_jwt(
    *,
    key_record_id: uuid.UUID,
    tenant_id: uuid.UUID,
    scopes: list[str],
    purpose: str | None = None,
) -> str:
    """Short-lived JWT so downstream validate_access_token accepts API-key callers."""
    now = int(time.time())
    payload: dict[str, Any] = {
        "sub": f"apikey:{key_record_id}",
        "iss": ISSUER,
        "azp": "controlplane-api-key",
        "iat": now,
        "exp": now + TTL_SECONDS,
        "spanopticon_auth": "api_key",
        "https://spanopticon.dev/tenant_id": str(tenant_id),
        "scope": " ".join(scopes),
    }
    if purpose:
        payload["purpose"] = purpose
    secret = next(iter(api_key_exchange_secrets()), None)
    if not secret:
        raise RuntimeError("API_KEY_EXCHANGE_JWT_SECRET is unset or is a published default")
    return jwt.encode(
        payload,
        secret,
        algorithm=ALG,
    )


def try_decode_api_key_session_jwt(token: str) -> dict[str, Any] | None:
    """Return claims if token is a valid API-key exchange JWT; else None."""
    for secret in api_key_exchange_secrets():
        if not secret:
            continue
        try:
            payload = jwt.decode(
                token,
                secret,
                algorithms=[ALG],
                issuer=ISSUER,
                options={"require": ["exp", "sub", "iss"]},
            )
        except InvalidTokenError:
            continue
        break
    else:
        return None
    if payload.get("spanopticon_auth") != "api_key":
        return None
    try:require_original_run(payload)
    except InvalidTokenError:return None
    return payload
